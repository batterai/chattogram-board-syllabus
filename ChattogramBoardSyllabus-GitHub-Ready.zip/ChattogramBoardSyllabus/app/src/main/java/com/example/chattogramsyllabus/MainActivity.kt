package com.example.chattogramsyllabus

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val green = Color.rgb(18, 112, 62)
    private val darkGreen = Color.rgb(11, 82, 45)
    private val paleGreen = Color.rgb(235, 248, 239)
    private val classes = listOf(
        "প্লে" to "play.pdf",
        "নার্সারি" to "nursery.pdf",
        "প্রথম শ্রেণি" to "class1.pdf",
        "দ্বিতীয় শ্রেণি" to "class2.pdf",
        "তৃতীয় শ্রেণি" to "class3.pdf",
        "চতুর্থ শ্রেণি" to "class4.pdf"
    )

    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var pageIndex = 0
    private var pdfTitle = ""
    private lateinit var root: LinearLayout
    private lateinit var pageImage: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var prevButton: Button
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
    }

    private fun showHome() {
        closePdf()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 250, 247))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(26), dp(20), dp(24))
            setBackgroundColor(green)
        }
        header.addView(text("চট্টগ্রাম বোর্ডের সিলেবাস", 23f, Color.WHITE, true))
        header.addView(text("প্লে থেকে চতুর্থ শ্রেণি", 14f, Color.rgb(224, 245, 231)).apply {
            setPadding(0, dp(7), 0, 0)
        })
        root.addView(header)

        val intro = text("আপনার শ্রেণি নির্বাচন করুন", 17f, darkGreen, true).apply {
            setPadding(dp(18), dp(20), dp(18), dp(8))
        }
        root.addView(intro)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(20))
        }
        classes.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(15), dp(14), dp(15))
                setBackgroundColor(Color.WHITE)
                elevation = dp(2).toFloat()
            }
            val number = TextView(this).apply {
                text = "${index + 1}"
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setTypeface(null, android.graphics.Typeface.BOLD)
                setBackgroundColor(green)
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            }
            val label = text(item.first, 17f, darkGreen, true).apply {
                setPadding(dp(14), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val open = Button(this).apply {
                text = "পড়ুন"
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
                setOnClickListener { openPdf(item.first, item.second) }
            }
            card.addView(number)
            card.addView(label)
            card.addView(open)
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
            list.addView(card, params)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun openPdf(title: String, assetName: String) {
        try {
            closePdf()
            val file = File(cacheDir, assetName)
            assets.open("syllabus/$assetName").use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(descriptor!!)
            pdfTitle = title
            pageIndex = 0
            showReader()
            renderPage()
        } catch (e: Exception) {
            Toast.makeText(this, "PDF খোলা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showReader() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(242, 247, 243))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(green)
        }
        val back = Button(this).apply {
            text = "← ফিরে যান"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkGreen))
            setOnClickListener { showHome() }
        }
        top.addView(back)
        top.addView(text(pdfTitle, 17f, Color.WHITE, true).apply {
            setPadding(dp(10), 0, 0, 0)
        })
        root.addView(top)

        pageLabel = text("", 14f, darkGreen, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(pageLabel)

        val scroll = ScrollView(this)
        pageImage = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(pageImage, ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(paleGreen)
        }
        prevButton = Button(this).apply {
            text = "আগের পৃষ্ঠা"
            setOnClickListener { if (pageIndex > 0) { pageIndex--; renderPage() } }
        }
        nextButton = Button(this).apply {
            text = "পরের পৃষ্ঠা"
            setOnClickListener {
                val count = renderer?.pageCount ?: 0
                if (pageIndex < count - 1) { pageIndex++; renderPage() }
            }
        }
        controls.addView(prevButton)
        controls.addView(nextButton)
        root.addView(controls)
        setContentView(root)
    }

    private fun renderPage() {
        val pdf = renderer ?: return
        val page = pdf.openPage(pageIndex)
        val width = (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(300)
        val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        pageImage.setImageBitmap(bitmap)
        pageLabel.text = "$pdfTitle  •  পৃষ্ঠা ${pageIndex + 1} / ${pdf.pageCount}"
        prevButton.isEnabled = pageIndex > 0
        nextButton.isEnabled = pageIndex < pdf.pageCount - 1
    }

    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        try { descriptor?.close() } catch (_: Exception) {}
        renderer = null
        descriptor = null
    }

    override fun onDestroy() {
        closePdf()
        super.onDestroy()
    }
}
