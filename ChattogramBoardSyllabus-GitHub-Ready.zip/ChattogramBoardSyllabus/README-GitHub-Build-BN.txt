চট্টগ্রাম বোর্ডের সিলেবাস APK তৈরি — GitHub মোবাইল নির্দেশনা

১) এই ZIP ফাইলটি Extract করবেন না। ZIP ফাইলটি GitHub Repository-তে আপলোড করতে হবে।
২) ZIP ফাইলের নাম ঠিক রাখুন: ChattogramBoardSyllabus-Android-Project.zip
৩) Repository-তে Add file > Upload files দিয়ে ZIP আপলোড করুন।
৪) Repository-তে Add file > Create new file নির্বাচন করুন।
৫) ফাইলের নাম দিন: .github/workflows/android.yml
৬) এই প্যাকেজের .github/workflows/android.yml ফাইলের সম্পূর্ণ লেখা কপি করে GitHub-এ পেস্ট করুন এবং Commit changes করুন।
৭) Actions ট্যাবে Build Android APK workflow চালু করুন।
৮) সফল হলে Actions-এর run খুলে Artifacts থেকে ChattogramBoardSyllabus-debug-apk ডাউনলোড করুন।

দ্রষ্টব্য: অ্যাপে বর্তমানে প্লে, নার্সারি ও প্রথম থেকে চতুর্থ শ্রেণির PDF অন্তর্ভুক্ত।
